Requires python 2.7.8

to run 

>python GoLSim
